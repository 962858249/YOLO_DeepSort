#set_model='pt'/'onnx'与'--yolo_weights'==‘yolov5s.pt’/'yolov5s.onnx'要对应
#因为onnx模型里面还不知道有没有names，所以如果更改模型的话需要修改一下
